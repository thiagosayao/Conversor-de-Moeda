﻿namespace ConversorDeMoedas
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbValorDolar = new System.Windows.Forms.ComboBox();
            this.txtValorReal = new System.Windows.Forms.TextBox();
            this.txtConverteReal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbValorReal = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtValorDolar = new System.Windows.Forms.TextBox();
            this.txtConverteDolar = new System.Windows.Forms.TextBox();
            this.cmbValorEuro = new System.Windows.Forms.ComboBox();
            this.txtValorEuro = new System.Windows.Forms.TextBox();
            this.txtConverteEuro = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbValorDolar
            // 
            this.cmbValorDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbValorDolar.FormattingEnabled = true;
            this.cmbValorDolar.Location = new System.Drawing.Point(159, 159);
            this.cmbValorDolar.Name = "cmbValorDolar";
            this.cmbValorDolar.Size = new System.Drawing.Size(87, 24);
            this.cmbValorDolar.TabIndex = 1;
            this.cmbValorDolar.SelectedIndexChanged += new System.EventHandler(this.cmbValorDolar_SelectedIndexChanged);
            // 
            // txtValorReal
            // 
            this.txtValorReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorReal.Location = new System.Drawing.Point(30, 106);
            this.txtValorReal.Name = "txtValorReal";
            this.txtValorReal.Size = new System.Drawing.Size(87, 22);
            this.txtValorReal.TabIndex = 2;
            this.txtValorReal.TextChanged += new System.EventHandler(this.txtValor_TextChanged);
            // 
            // txtConverteReal
            // 
            this.txtConverteReal.Enabled = false;
            this.txtConverteReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConverteReal.Location = new System.Drawing.Point(30, 209);
            this.txtConverteReal.Name = "txtConverteReal";
            this.txtConverteReal.Size = new System.Drawing.Size(87, 22);
            this.txtConverteReal.TabIndex = 3;
            this.txtConverteReal.TextChanged += new System.EventHandler(this.txtConverte_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(95, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "Conversor de Moedas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "valor";
            // 
            // cmbValorReal
            // 
            this.cmbValorReal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbValorReal.FormattingEnabled = true;
            this.cmbValorReal.Location = new System.Drawing.Point(30, 159);
            this.cmbValorReal.Name = "cmbValorReal";
            this.cmbValorReal.Size = new System.Drawing.Size(87, 24);
            this.cmbValorReal.TabIndex = 0;
            this.cmbValorReal.SelectedIndexChanged += new System.EventHandler(this.cmbValorReal__SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(27, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Real";
            // 
            // txtValorDolar
            // 
            this.txtValorDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorDolar.Location = new System.Drawing.Point(159, 106);
            this.txtValorDolar.Name = "txtValorDolar";
            this.txtValorDolar.Size = new System.Drawing.Size(87, 22);
            this.txtValorDolar.TabIndex = 8;
            this.txtValorDolar.TextChanged += new System.EventHandler(this.txtValorDolar_TextChanged);
            // 
            // txtConverteDolar
            // 
            this.txtConverteDolar.Enabled = false;
            this.txtConverteDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConverteDolar.Location = new System.Drawing.Point(159, 209);
            this.txtConverteDolar.Name = "txtConverteDolar";
            this.txtConverteDolar.Size = new System.Drawing.Size(87, 22);
            this.txtConverteDolar.TabIndex = 9;
            // 
            // cmbValorEuro
            // 
            this.cmbValorEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbValorEuro.FormattingEnabled = true;
            this.cmbValorEuro.Location = new System.Drawing.Point(287, 159);
            this.cmbValorEuro.Name = "cmbValorEuro";
            this.cmbValorEuro.Size = new System.Drawing.Size(87, 24);
            this.cmbValorEuro.TabIndex = 10;
            this.cmbValorEuro.SelectedIndexChanged += new System.EventHandler(this.cmbValorEuro_SelectedIndexChanged);
            // 
            // txtValorEuro
            // 
            this.txtValorEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValorEuro.Location = new System.Drawing.Point(287, 106);
            this.txtValorEuro.Name = "txtValorEuro";
            this.txtValorEuro.Size = new System.Drawing.Size(87, 22);
            this.txtValorEuro.TabIndex = 11;
            // 
            // txtConverteEuro
            // 
            this.txtConverteEuro.Enabled = false;
            this.txtConverteEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtConverteEuro.Location = new System.Drawing.Point(287, 209);
            this.txtConverteEuro.Name = "txtConverteEuro";
            this.txtConverteEuro.Size = new System.Drawing.Size(87, 22);
            this.txtConverteEuro.TabIndex = 12;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(155, 56);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 20);
            this.label5.TabIndex = 13;
            this.label5.Text = " Dólar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(283, 56);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(52, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = " Euro";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(156, 87);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 16);
            this.label9.TabIndex = 17;
            this.label9.Text = "valor";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(284, 87);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 16);
            this.label10.TabIndex = 18;
            this.label10.Text = "valor";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "para";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(159, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 16);
            this.label7.TabIndex = 20;
            this.label7.Text = "para";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(287, 140);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 16);
            this.label8.TabIndex = 21;
            this.label8.Text = "para";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(34, 190);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 16);
            this.label11.TabIndex = 22;
            this.label11.Text = "valor";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(162, 190);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 16);
            this.label12.TabIndex = 23;
            this.label12.Text = "valor";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(290, 190);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 16);
            this.label13.TabIndex = 24;
            this.label13.Text = "valor";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(414, 262);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtConverteEuro);
            this.Controls.Add(this.txtValorEuro);
            this.Controls.Add(this.cmbValorEuro);
            this.Controls.Add(this.txtConverteDolar);
            this.Controls.Add(this.txtValorDolar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtConverteReal);
            this.Controls.Add(this.txtValorReal);
            this.Controls.Add(this.cmbValorDolar);
            this.Controls.Add(this.cmbValorReal);
            this.Name = "Form1";
            this.Text = "Conversor de Moedas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmbValorDolar;
        private System.Windows.Forms.TextBox txtValorReal;
        private System.Windows.Forms.TextBox txtConverteReal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbValorReal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtValorDolar;
        private System.Windows.Forms.TextBox txtConverteDolar;
        private System.Windows.Forms.ComboBox cmbValorEuro;
        private System.Windows.Forms.TextBox txtValorEuro;
        private System.Windows.Forms.TextBox txtConverteEuro;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}

